"""To load django signals"""
